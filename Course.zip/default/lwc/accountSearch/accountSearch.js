import { LightningElement } from 'lwc';
import fetchAccount from '@salesforce/apex/DataFetch.fetchAccountData';
const columnHeader = [
    {label:'Name',fieldName:'Name'},
    {label:'Phone',fieldName:'Phone'},
    {label:'Type',fieldName:'Type'},
    {label:'Industry',fieldName:'Industry'}
];
export default class AccountSearch extends LightningElement {


    key = '';
    isShow;
    accountData;
    accountError;
    columnDescription = columnHeader;
    handleChange(e)
    {
        this.key = e.target.value;
        if(this.key === '')
        {
            this.key = '@#$%&()';
            this.isShow = false;
        }
        else
        {
            this.isShow = true;

        }
        console.log(this.key);
        this.fetchData();

    }

    fetchData()
    {
       fetchAccount({value:this.key}).then(result => {
        this.accountData = result;
        this.accountError= undefined;
        console.log(this.accountData);
       }).catch(error=>{
        this.accountData = undefined;
        this.accountError= error;
       }) 
    }

}