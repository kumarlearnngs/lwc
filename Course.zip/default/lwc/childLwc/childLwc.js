import { LightningElement,api } from 'lwc';

export default class ChildLwc extends LightningElement {

    @api message ;
    basic = "This is the Child Class variable";
    @api childToParent = "This is the Child Class variable";

    @api childMethod(parentvalue)
    {
        this.basic = parentvalue;
    }
    handleCustomEvent()
    {
        const eventCustom = new CustomEvent('childdata',{
            detail:{
                name : 'Iphone 13 Pro Max',
                color: 'grey',
                size : '6.7 inches'
            },bubbles:true,composed:true
        });
        this.dispatchEvent(eventCustom);
    }
}