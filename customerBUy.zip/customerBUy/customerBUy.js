import { LightningElement, wire } from 'lwc';
import model from'@salesforce/apex/BuyCustomer.sendModel';
const  columns = [{'label':'Name','fieldName':'Name','type':'text'},
{'label':'Car Name','fieldName':'Car__r.Name','type':'text'},
{'label':'Engine','fieldName':'Engine__c','type':'text'},
{'label':'Model','fieldName':'Model__c','type':'text'},
{'label':'Price','fieldName':'Price__c','type':'currency'}];
export default class CustomerBUy extends LightningElement {
 key='@$#$';
columns = columns;
@wire(model,{modelName:'$key'})
carmodel;

}