import { LightningElement, wire } from 'lwc';
import fetchAccount from '@salesforce/apex/DataFetch.fetchAccountData';
import fetchContact from '@salesforce/apex/DataFetch.fetchContactData';
const columns = [
    { label: 'Name', fieldName: 'Name' },
    { label: 'Phone', fieldName: 'Phone', type: 'phone' }
  ];
export default class WireLearn extends LightningElement {


   // @wire(fetchAccount)
   // accountData; //load automatically but after lifecycle hooks
    result;
    error;
    contactResult;
    contactError;
    name = 'United';

    contactColumn = columns;

   @wire(fetchAccount,{key:'$name'})
   accountData({error,data})
   {
       if(data)
       {
           this.result = data;
           this.error = undefined;
           console.table(this.result);

       }
       else
       if(error)
       {
           this.result = undefined;
           this.error =error;
       }

   }





    handleClick()
    {
        fetchContact().then( contactData =>{
            this.contactResult = contactData;
            this.contactError = undefined;
        }).catch(conerror=>
            {
                this.contactResult = undefined;
                this.contactError = conerror;



            }
        )
        console.table(this.contactResult);
       
    }


}