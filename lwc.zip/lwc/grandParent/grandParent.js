import { LightningElement } from 'lwc';

export default class GrandParent extends LightningElement {


    handleGrandParent()
    {
        console.log("GrandParent Data Fired Bubbles true Composed true");

    }
}