import { LightningElement } from 'lwc';

export default class SecondLWC extends LightningElement {}