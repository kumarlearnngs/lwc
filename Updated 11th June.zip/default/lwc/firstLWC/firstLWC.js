import firsthtml from './firstLWC.html';
import secondhtml from './firstLWC2.html';
import { LightningElement } from 'lwc';
export default class FirstLWC extends LightningElement {
greeting = "Good Morning";
isShow =true;
connectedCallback() { //called once
    this.greeting = "Good Afternoon";
     console.log('connectedCallback is Loaded');
}
handleClick(){
 

  if(this.greeting === "Good Night")
  {
    this.greeting = "Good Evening";
    this.isShow=true;
  }
    else
    {
    this.greeting = "Good Night";
    this.isShow = false;
    }
}


renderedCallback() // called whenever page DOM changes - multiple time
{
   console.log('renderedCallback is Loaded'); 
}
constructor() //called once
{
    super();
   console.log('Constructor is Loaded');
}
render()
{
    console.log('Render Loaded');
    if(this.greeting === "Good Night")
    {
        return firsthtml;
    }
    else
    {
        return secondhtml;
    }
}

/*errorCallback(error) {
     console.log('ErrorCallback is Loaded');
     console.log(error);
}*/

disconnectedCallback() {
    //code
    console.log('disconnectedCallback is Loaded');
}
handleAnchor(e)
{
    e.preventDefault();
    
    console.log("Anchor Ran");
}

}