({
	handleChildClick : function(component, event, helper) {
		var childEvent = component.getEvent("SendToParent");
        childEvent.setParams({"ChildData":"This is the data sent from Child"});
        childEvent.fire();
	}
})