({
	handleClick : function(component, event, helper) {
		component.set("v.parentValue","This is the data from Parent");
	},
    handleEventData: function(component, event, helper) {
        var eventData = event.getParam("ChildData");
		component.set("v.ReceiveChildData",eventData);
	}
})