import { LightningElement } from 'lwc';
import getContactData from '@salesforce/apex/ContactData.fetchContact';
const col = [
    {label:"Name",fieldName:"Name",type:"text"},
    {label:"Phone",fieldName:"Phone",type:"phone"},
    {label:"Email",fieldName:"Email",type:"email"}
]
export default class SearchComponent extends LightningElement {
    pageSize = 5;
    searchKey;
    result;
    error;
    columns = col;
    isShow =false;
    startPage=0;
    EndPage=5;
    temp = [];
    tempResult;
    handleContact(event)
    {
      
      this.searchKey = event.target.value;
      
      if(this.searchKey === "")
      {
          this.searchKey = '@#$%&*';
          this.isShow=false;
      }
      console.log(this.searchKey)
      this.receiveContactData();
    }
    handleNext()
    {
        this.startPage = this.startPage + this.pageSize; //5 //10
        this.EndPage = this.EndPage +this.pageSize;//10 //15
        this.handlePaginaion();
    }
    handlePrevious()
    {
        this.startPage = this.startPage - this.pageSize;
        this.EndPage = this.EndPage -this.pageSize;
        this.handlePaginaion();
    }
    handlePaginaion() //12 data
    {console.log('length '+this.tempResult.length);
        if(this.tempResult.length > this.pageSize)
            {
                for(let i=this.startPage;i<this.EndPage;i++) //0,4
                { 
                    if(i <= this.tempResult.length )
                    {
                    this.temp.push(this.tempResult[i]);
                    }
                    
                   
                }
                console.log('temp value '+this.temp);
                this.result = this.temp; //result have value 5
                this.temp=[]; //temp is null
            }
            else
           this.result = this.tempResult;
    }
    receiveContactData()
    { 
        getContactData({"searchValue":this.searchKey}).then( res => {
           
          this.tempResult =res;
          console.table(this.tempResult); //12 data
          this.handlePaginaion();
          if(this.searchKey === '@#$%&*')
          this.isShow = false;
          else
          this.isShow = true;
        })
        .catch(err=>{
            this.error =err;
        })
        
        
    }
}