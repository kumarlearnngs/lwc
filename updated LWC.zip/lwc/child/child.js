import { LightningElement,api } from 'lwc';

export default class Child extends LightningElement {

    message="The is private Child Data";
    @api publicvariable="This is the data from Child";

    @api setChildMethod(data)
    {
        this.message = data;
    }
    @api getChildMethod()
    {
        return this.message;
    }
    sendDataToParent()
    {
        const eventCustom = new CustomEvent('childdata',{
            detail:{
                name : "Iphone 13 Pro Max",
                color:"grey",
                size:"6.7 inches"
            }
        });
        this.dispatchEvent(eventCustom);
    }

}