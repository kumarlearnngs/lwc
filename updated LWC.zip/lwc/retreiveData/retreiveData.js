import { LightningElement,wire } from 'lwc';
import getAccount from '@salesforce/apex/LwcConnector.fetchAccount';
const col = [
    {label:'Account Name',fieldName:'Name',type:'text'},
    {label:'Account Phone',fieldName:'Phone',type:'phone'},
    {label:'Account AR',fieldName:'AnnualRevenue',type:'number'}


];

export default class RetreiveData extends LightningElement {


   // @wire(getAccount)
 //   accountData;
result;
error;
columns = col;
/*
 @wire(getAccount)
   accountData({error,data})
   {
       if(data)
       {
           this.result = data;
           this.error = undefined;
           console.table(this.result);


       }
       else
       if(error)
       {
           this.result = undefined;
           this.error = error;
       }
   }
*/
handleFetchData()
{
    getAccount().then(res =>{
        this.result = res;
    })
    .catch(err =>{
        this.error = err;
    })
}
    /// function(res)
}