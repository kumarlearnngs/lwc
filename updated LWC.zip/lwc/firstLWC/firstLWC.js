import { LightningElement } from 'lwc';
import animals from '@salesforce/resourceUrl/animals';
import lionhtml from './lion.html';
import elephanthtml from './elephant.html';
import pandahtml from './panda.html';
import tigerhtml from './tiger.html';
import mainPageHtml from './firstLWC.html';


export default class FirstLWC extends LightningElement {

    greeting; //member variable with no data type
    inputText;
    lion;
    elephant;
    panda;
    tiger;
    currentScreen;

  handleClick() //functiion in js
  {
    this.currentScreen='elephant';
    if(this.greeting === "Hi Everyone Good Morning")
    {
       this.greeting = "Hi Everyone Good Afternoon";
    }
    else
    {
        this.greeting = "Hi Everyone Good Morning" ;
    }
  }
  constructor()
  {
      super();
      this.greeting = "Hi Everyone Good Morning";
      console.log("This is Constructor");
      this.lion = animals +'/animals/lion.jpg';
      this.elephant = animals +'/animals/elephant.jpg';
      this.panda = animals +'/animals/panda.jpg';
      this.tiger = animals +'/animals/tiger.jpg';
      console.log(this.lion);
      console.log(this.elephant);
      console.log(this.panda);
      console.log(this.tiger);
      this.currentScreen = 'mainPage';

  }
  connectedCallback()
  {
    console.log("This is ConnectedCallback");
  }
  renderedCallback()
  {
    console.log("This is RenderedCallback");
  }

  handleKeyData(kanhaiya)
  {
    this.inputText = kanhaiya.target.value;
  }

  handleElephant()
  {
     this.currentScreen='lion';
  }
  handleLion()
  {
    this.currentScreen='panda';
  }
  handlePanda()
  {
    this.currentScreen='tiger';
  }
  handleTiger()
  {
    this.currentScreen='mainPage';
  }
  render()
  {
    console.log('Inside Render');

    if(this.currentScreen === "mainPage")
    {
      return elephanthtml;
    }
    else if(this.currentScreen === "elephant")
    {
      return lionhtml;
    }
    else if(this.currentScreen === "lion")
    {
      return pandahtml;
    }
    else if(this.currentScreen === "panda")
    {
      return tigerhtml;
    }
    else if(this.currentScreen === "tiger")
    {
      return mainPageHtml;
    }




  }

}