import { LightningElement } from 'lwc';

export default class RecordForm extends LightningElement {}