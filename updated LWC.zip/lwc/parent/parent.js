import { LightningElement } from 'lwc';

export default class Parent extends LightningElement {

    updateChild ="Initialized by Parent";
    childData;
    phonename;
    phonecolor;
    phonesize;

    renderedCallback()
    {
        this.childData = this.template.querySelector("c-child").getChildMethod();
    }

    handleParent()
    {
        console.log(this.template.querySelector("c-child").publicvariable);
        this.template.querySelector("c-child").publicvariable = 'The data is provided from Parent';
        this.template.querySelector("c-child").setChildMethod("The message data is updated irrespective of it being private");
    }
    handleParentData(event)
    {
        this.phonename = event.detail.name;
        this.phonecolor = event.detail.color;
        this.phonesize = event.detail.size;

    }
}