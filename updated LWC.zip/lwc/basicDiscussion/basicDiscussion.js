import { LightningElement,wire } from 'lwc';
import getAccount from '@salesforce/apex/LwcConnector.fetchAccount';
const columns = [
    {label:'Name',fieldName:'Name',type:'text'},
    {label:'Account Phone',fieldName:'Phone',type:'phone'},
    {label:'Account AR',fieldName:'AnnualRevenue',type:'number'}

];
export default class BasicDiscussion extends LightningElement {
   
    greeting = "Hello Good Morning";
    cols = columns; 
    result;
    error;
    searchKey;
   
   
    /*@wire(getAccount)
    result;*/
   //imperative call
handleData(ajay)
{
    console.log(ajay.target.value);
    this.searchKey = ajay.target.value;
    this.handleClick();
}
handleClick()
{
    getAccount({'search':this.searchKey}).then( accData => {
      this.result= accData;
    }).catch(er => {
        this.error=er;
    });
}
   
   
    constructor()
    {
        super();
        console.log('Constructor called');
    }
    connectedCallback()
    {
        console.log('Connected Callback called');
    }
    renderedCallback()
    {
        console.log('Rendered Callback called');
    }
   /* handleClick()
    {
        if(this.greeting === "Hello Good Morning")
        {
            this.greeting ="Hello Good Afternoon"; //reactive behaviour
        }
        else
        {
            this.greeting = "Hello Good Morning";
        }
    }*/

  


}