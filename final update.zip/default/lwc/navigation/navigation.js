import { LightningElement } from 'lwc';
import {NavigationMixin} from 'lightning/navigation';

export default class Navigation extends NavigationMixin(LightningElement) {

    handleClick()
    {
        console.log('Ran Handle Click');
   // this.navigateToObjectDetailPage();
        this.navigateToWebPage();  
    }

    navigateToObjectDetailPage()
    {
        console.log('Ran object page');
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Case',
                actionName: 'home'
            }
        });
    }
    navigateToListView()
    {
        console.log('Ran object page');
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Account',
                actionName: 'list'
            },
            state:{
                filterName : '00B5i0000010d7KEAQ'
            }
        });
    }

    navigateToRecordPageNew()
    {
        console.log('Ran object page');
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'Account',
                actionName: 'new'
            }
            
        });
    }

    navigateToRecordPageEdit()
    {
        console.log('Ran object page');
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: '00Q5i000003wNjIEAU',
                objectApiName: 'Lead',
                actionName: 'edit'
            }
            
        });
    }

    navigateToRelatedList()
    {
        console.log('Ran object page');
        this[NavigationMixin.Navigate]({
            type: 'standard__recordRelationshipPage',
            attributes: {
                recordId: '0015i000008ChFLAA0',
                objectApiName: 'Account',
                relationshipApiName : 'Contacts',
                actionName: 'view'
            }
            
        });
    }

    navigateToWebPage()
    {
        console.log('Ran object page');
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: 'https://www.google.com'
            }
            
        });
    }
}