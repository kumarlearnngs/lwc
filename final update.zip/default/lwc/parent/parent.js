import { LightningElement } from 'lwc';

export default class Parent extends LightningElement {

    messageParent="This is a message from Parent";
    name;
    color;
    size;

    handleClick()
    {
        this.template.querySelector("c-child-lwc").childToParent = "This is parent data overiding child";
        console.log(this.template.querySelector("c-child-lwc").innerHTML);
        this.template.querySelector("c-child-lwc").childMethod("This data is overided through parent method");
    }

    handleParentdata(e)
    {
        console.log("Parent Data Fired Bubbles false Composed false");
        this.name = e.detail.name;
        this.color = e.detail.color;
        this.size = e.detail.size;

    }
    handleCustomData()
    {
        console.log("Parent Data Fired Bubbles true Composed false");
    }
    

   
}