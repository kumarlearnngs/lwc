({ /* domLockerController.js */
    peekInDom : function(cmp, event, helper) {
        console.log("cmp.getElements(): ", cmp.getElements());
        // access the DOM in c:domLocker
        console.log("div1: ", cmp.find("div1").getElement());
        console.log("button1: ", cmp.find("button1"));
        console.log("button name: ", event.getSource().get("v.name"));

         //returns an error
       // console.log("button1 element: ", cmp.find("button1").getElement());
    },
    
    doInit :  function(cmp, event, helper) {
        
        $A.createComponent(
            "lightning:button",
            {
                "aura:id" :"myButton2",
                "label" :"Dynamic Button",
                "onclick":cmp.getReference("c.handleDynamicButton")
            },
            function(dynamicButton,status,error)
            {
                if(status === "SUCCESS")
                {
                   var body = cmp.get("v.body");
                    body.push(dynamicButton);
                    cmp.set("v.body",body);
                }
            }
                          
                          
                          
                          );
    },
            handleDynamicButton : function(cmp,event,helper)
        {
            console.log("button is pressed which is "+cmp.find("myButton2"));
        }
})