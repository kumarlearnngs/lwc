({
	handleSearch : function(component, event, helper) {
		var searchvalue =  component.find("searchField").get("v.value");
        if(searchvalue === '')
        {
           component.set("v.isShow",false); 
        }
        else
        {
            component.set("v.isShow",true); 
        }
        console.log(searchvalue);
        helper.fetchOppty(searchvalue,component);
	}
})