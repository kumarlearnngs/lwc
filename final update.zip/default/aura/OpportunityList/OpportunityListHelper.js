({
	fetchOppty : function(sear,cmp) {
		cmp.set("v.columnsToDisplay",[
            {label:'Opportunity Name',fieldName:'Name',type:"text"},
            {label:'Close Date',fieldName:'CloseDate',type:"date"},
            {label:'Stage',fieldName:'StageName',type:"text"}
        ]);
	
    
    var action = cmp.get("c.fetchOpportunity");
    action.setParams({"search":sear});
    action.setCallback(this, function(response)
    {
    var state = response.getState();
    if(state === "SUCCESS")
    {
    cmp.set("v.opptylist",response.getReturnValue());
}
});
$A.enqueueAction(action);
        
        }
    
    
})