({
	handleApplicationData : function(component, event, helper) {
        
        var genData = event.getParam("GenericData");
        component.set("v.ReceiveData",genData);
        var counterInfo = parseInt(component.get("v.Counter"))+1;
        component.set("v.Counter",counterInfo);
		
	}
})