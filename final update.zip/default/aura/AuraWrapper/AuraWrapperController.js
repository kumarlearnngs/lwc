({
	handleData : function(cmp, event, helper) {
        cmp.set("v.isShow",true);
		  var action = cmp.get("c.fetchWrapperData");
    action.setCallback(this, function(response)
    {
    var state = response.getState();
    if(state === "SUCCESS")
    {
    cmp.set("v.WrapperList",response.getReturnValue());
        console.log("Data Loaded");
        console.log(response.getReturnValue());
        console.log(cmp.get("v.WrapperList"));
}
});
$A.enqueueAction(action);
        
	}
})