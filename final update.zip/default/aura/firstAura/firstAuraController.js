({
	 myAction: function(component, event, helper) {
         var act = "SRK";
         component.set("v.actor",act);
		
	},
    
    	 callAccounts: function(component, event, helper) {
         var action = component.get("c.fetchContactData");
             action.setCallback(this,function(resp)
                                { var currentState = resp.getState();
                                 if(currentState === "SUCCESS")
                                 {
                                     var conData = resp.getReturnValue();
                                     component.set("v.accounts",conData);
                                 }
                                    
                                });
             $A.enqueueAction(action); // take care connection with apex
		
	}
})