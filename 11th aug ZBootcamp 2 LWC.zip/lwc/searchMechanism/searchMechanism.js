import { LightningElement, wire } from 'lwc';
import accountData from '@salesforce/apex/AccountSearchMechanism.accountFetch';
const columns = [
    {label:'Name',fieldName:'AccountUrl',type:'url',typeAttributes: {
        label: {fieldName : 'Name'},
        target: '_blank'
    }},
    {label:'Phone',fieldName:'Phone',type:'phone'},
    {label:'Industries',fieldName:'Industry',type:'text'}
];

export default class SearchMechanism extends LightningElement {

searchKey;
result;
error;
cols = columns;
baseUrl ;
renderedCallback()
{
    console.log(window.location.origin);
    this.baseUrl = window.location.origin
}
handleEvent(keyPressed)
{
   console.log(keyPressed.target.value);
   this.searchKey = keyPressed.target.value;
   this.handleData();
}

}
handleData()
{
    let modifiedResultArray= [];
    accountData({'SearchKeyValue' : this.searchKey}).then( result => {
        result.forEach( (mainData) => {
            let modifiedResult = {};
            modifiedResult.Name = mainData.Name;
            modifiedResult.Phone = mainData.Phone;
            modifiedResult.Industry = mainData.Industry;
            modifiedResult.Id = mainData.Id;
            modifiedResult.AccountUrl = this.baseUrl+'/lightning/r/Account/'+mainData.Id+'/view';
            modifiedResultArray.push(modifiedResult);
        })
        this.result = modifiedResultArray;
        console.table(result);
    } ).catch( error => {
        this.error = error;
    })
}

}