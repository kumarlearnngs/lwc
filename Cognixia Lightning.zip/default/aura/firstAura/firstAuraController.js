({
	handleGreeting : function(component, event, helper) {
        var greetingValue = 'Hello Good Morning';
        component.set("v.greeting",greetingValue);
		
	},
    	handleClick : function(component, event, helper) {
            
        var greetingValue = component.get("v.greeting");
            if(greetingValue === 'Hello Good Morning')
            {
              component.set("v.greeting","Hello Good Afternoon");  
            }
            else
            {
                component.set("v.greeting","Hello Good Morning"); 
            }
        
		
	},
    handleApexData : function(component, event, helper) {
        component.set("v.columns",[
            {
        label:'Name',
        fieldName:'Name',
        type:'text'
       
    },
    {
        label:'Phone',
        fieldName:'Phone',
        type:'phone'
    },
    {
        label:'Industry',
        fieldName:'Industry',
        type:'text'
    }
        ]);
        
       
        var action = component.get("c.fetchAccount");
        action.setCallback(this,function(resp){
                           var currentState = resp.getState();
                           if(currentState === "SUCCESS")
                           {
                               var accData = resp.getReturnValue();
                               component.set("v.accounts",accData);
                           }
                           });
		$A.enqueueAction(action);
	}
})