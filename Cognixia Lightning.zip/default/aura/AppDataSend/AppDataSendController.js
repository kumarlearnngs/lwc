({
	SendEvent : function(component, event, helper) {
        var appData = $A.get("e.c:AppEvent");
        appData.setParams({"GenericData":"This is the data sent as an Application Event"});
        appData.fire();
	}
})