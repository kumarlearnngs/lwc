({
	handleClick : function(component, event, helper) {
        console.log("btn Clicked");
		component.set("v.parentValue","This is the data sent from Parent");
	},
    handleEventData: function(component, event, helper) {
        
        var eventData = event.getParam("ChildData");
        component.set("v.ReceiveChildData",eventData);
    }
})