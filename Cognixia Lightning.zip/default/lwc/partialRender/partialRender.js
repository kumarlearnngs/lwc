import { LightningElement } from 'lwc';
import LAST_NAME from '@salesforce/schema/Lead.LastName';
import COMPANY from '@salesforce/schema/Lead.Company';
import checkuser from '@salesforce/apex/UserRender.checkUser';
export default class PartialRender extends LightningElement {

    fields = [LAST_NAME,COMPANY];
    isShow = checkuser;
    handleClick()
    {
       if(this.isShow)
       {
           this.isShow=false;
       }
       else
       {
           this.isShow = true;
       }
    }
}