import { LightningElement,api } from 'lwc';
import firsthtml from './firstComponent.html';
import secondhtml from './second.html';
import thirdhtml from './third.html';
export default class FirstComponent extends LightningElement {

greeting ;
template ;
@api fetchauradata;
connectedCallback()

{
    console.log('Connected Callback Ran');
}
constructor()
{
    super();
    this.greeting = 'Good Morning';
    console.log('Contsructor Loaded');
    this.template = 'first';
}
renderedCallback()
{
    console.log('Rendered Callback Ran');
}
handleClick()
{
    console.log('Inside Click');
    if(this.greeting === 'Good Morning')
    {
        this.greeting = 'Good Afternoon'; //Reactiveness
    }
    else
    {
        this.greeting = 'Good Morning';
    }

}
handleTemplate()

{
    if (this.template === 'first')
    {
        this.template='second';
    }
    else 
    if(this.template === 'second')
    {
        this.template='third';
    }
    else 
    if(this.template === 'third')
    {
        this.template='first';
    }
}

render()
{
    console.log('Render Ran');
    if (this.template === 'first')
    {
        return firsthtml;
    }
    else
    if(this.template === 'second')
    {
        return secondhtml;
    }
    else 
    if(this.template === 'third')
    {
        return thirdhtml;;
    }
}

}