import { LightningElement,track, wire } from 'lwc';
import { subscribe,unsubscribe,APPLICATION_SCOPE,MessageContext } from 'lightning/messageService';
import testChannel from '@salesforce/messageChannel/testChannel__c';
import getContact from '@salesforce/apex/OpportunityLMS.fetchOpportunity';
const column = [
    {label:"Name",fieldName:"Name",type:"text"},
    {label:"Close Date",fieldName:"CloseDate",type:"date"}
];
export default class ContactSearch extends LightningElement {
@track lmsMessage=[];
subscription = '';
result;
error;
columns = column;

@wire(MessageContext)
MessageContext;

connectedCallback()
{
    //subscription logic
    this.subscribeToMessageChannel();
}

subscribeToMessageChannel()
{
       if(!this.subscription)
       {
           this.subscription = subscribe(this.MessageContext,testChannel,(message) => this.handleSubscription(message),{scope:APPLICATION_SCOPE});
       }
}

handleSubscription(message)
{
    this.lmsMessage = message.inputValueMsg;
    getContact({recordIdValue : this.lmsMessage}).then( res => {
        this.result = res;
    }).catch(error => {
        this.error = error;
    })
}
unsubscribeToMessageChannel()
{
    unsubscribe(this.subscription);
    this.subscription = null;
}

disconnectedCallback()
{
    this.unsubscribeToMessageChannel();
}

}