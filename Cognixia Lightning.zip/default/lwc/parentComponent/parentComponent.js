import { LightningElement } from 'lwc';

export default class ParentComponent extends LightningElement {
    directParentValue = "This is direct value from Parent";
    Name;
    Color;
    Size;
    Name1;
    Color1;
    Size1;
    handleClick()
    {
        this.template.querySelector('c-child-component').message = 'This is the modified data from parent';
        console.log('Child Data',this.template.querySelector('c-child-component').message);
        this.template.querySelector('c-child-component').childMethod('Updating private from Parent');
    }
    handleParentCustomEvent(vincent)
    {
        this.Name = vincent.detail.Name;
        this.Color = vincent.detail.Color;
        this.Size = vincent.detail.Size;

    }
    handleTreeEvent(vincent)
    {
        this.Name1 = vincent.detail.Name;
        this.Color1 = vincent.detail.Color;
        this.Size1 = vincent.detail.Size;
        console.log('Tree Event fired');
        console.log( this.Name1+ this.Color1+this.Size1);
        vincent.stopPropagation();
    }
    handleanchor(event)
    {
        event.preventDefault();
        console.log('Clicked');
    }
}