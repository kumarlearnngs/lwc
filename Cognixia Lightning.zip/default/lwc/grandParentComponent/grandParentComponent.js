import { LightningElement } from 'lwc';

export default class GrandParentComponent extends LightningElement {
    Name1;
    Color1;
    Size1;
    handleGrandparent(vincent)
    {
        this.Name1 = vincent.detail.Name;
        this.Color1 = vincent.detail.Color;
        this.Size1 = vincent.detail.Size;
        console.log('GrandParent Event fired');
        console.log( this.Name1+ this.Color1+this.Size1);

    }

}