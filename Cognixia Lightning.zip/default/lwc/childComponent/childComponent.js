import { LightningElement,api } from 'lwc';

export default class ChildComponent extends LightningElement {

    @api message = 'This is from Child Component'; //private in nature
    messagedata = ' This is second data from Child Component';
    @api directValue;

    @api childMethod(message)
    {
        this.messagedata = message;
    }
    handleEvents()
    {
        const eventData = new CustomEvent('childevent',{
             detail : {
                 'Name':'Iphone 13 Pro Max',
                 'Color':'Blue',
                 'Size':'6.7 inches'
             },bubbles:true,composed:true
        });
        this.dispatchEvent(eventData);
    }
}