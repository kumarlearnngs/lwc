import { LightningElement,wire } from 'lwc';
import getAccount  from '@salesforce/apex/DataController.fetchAccount';
import getContact  from '@salesforce/apex/DataController.fetchContact';
const col = [
    {
        label:'Name',
        fieldName:'ContactUrl',
        type:'url',
        typeAttributes:{
            label:{
            fieldName:'Name'
            }
        }
    },
    {
        label:'Account Name',
        fieldName:'RecordDetail',
        type:'url',
        typeAttributes:{
            label:{
            fieldName:'AccountName'
            }
        }
    },
    {
        label:'Phone',
        fieldName:'Phone',
        type:'phone'
    },
    {
        label:'Email',
        fieldName:'Email',
        type:'email'
    }
];

const cols = [
    {
        label:'Name',
        fieldName:'RecordDetail',
        type:'url',
        typeAttributes:{
            label:{
            fieldName:'Name'
            }
        }
    },
    {
        label:'Phone',
        fieldName:'Phone',
        type:'phone'
    },
    {
        label:'AR',
        fieldName:'AnnualRevenue',
        type:'currency'
    }
];

export default class RetrieveData extends LightningElement {

//@wire(function connected to Apex)
//variable or a function;
columns = cols;
contactColumns = col;
result;
conResult;
conError;
error;
searchKey = 'United';

currentClicked;
handleKeys(e)
{
     this.searchKey = e.target.value; //typing in input box

     this.handleAccountData();
}
//@wire(getAccount)
//accountData;
/*
@wire(getAccount,{Search : '$searchKey'})
accountData({error,data})
{
    if(data)
    {
       this.result =data;
       this.error = undefined;
       console.table(data);
    }
    else
    {
        this.error = error;
        this.result= undefined;

    }
}
*/

handleAccountData()
{
    getAccount({'Search':this.searchKey}).then( res =>{ 
             //function(res)

             if(res)
             {
                 let finalChange=[];
                 res.forEach( row =>{
                     let objectStruct = {};
                     objectStruct.Id = row.Id;
                     objectStruct.Name = row.Name;
                     objectStruct.Phone = row.Phone;
                     objectStruct.AnnualRevenue = row.AnnualRevenue;
                     objectStruct.RecordDetail = 'https://learnngs41-dev-ed.lightning.force.com/lightning/r/Account/'+row.Id+'/view';
                     finalChange.push(objectStruct);
                 })
                 this.result = finalChange;
             }
        
            
    }).catch(err => {
        this.error=err;

    })

this.handleContactData();
  
}

handleContactData()
{
    getContact({'Search':this.searchKey}).then( res =>{ 
        //function(res)

        if(res)
        {
            let finalChange=[];
            res.forEach( row =>{
                let objectStruct = {};
                objectStruct.Id = row.Id;
                objectStruct.Name = row.Name;
                objectStruct.Phone = row.Phone;
                objectStruct.Email = row.Email;
                objectStruct.AccountName = row.Account.Name;
                objectStruct.ContactUrl = objectStruct.RecordDetail = 'https://learnngs41-dev-ed.lightning.force.com/lightning/r/Contact/'+row.Id+'/view';
                objectStruct.RecordDetail = 'https://learnngs41-dev-ed.lightning.force.com/lightning/r/Account/'+row.AccountId+'/view';
                finalChange.push(objectStruct);
            })
            this.conResult = finalChange;
        }
    }).catch(err => {
        this.conError=err;

    })

}





}