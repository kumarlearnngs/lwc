import { LightningElement, wire } from 'lwc';
import {publish,MessageContext} from 'lightning/messageService';
import testChannel from '@salesforce/messageChannel/testChannel__c';
import getAccount from '@salesforce/apex/AccountLMS.fetchAccount';
const column = [
    {label:"Name",fieldName:"Name",type:"text"},
    {label:"Phone",fieldName:"Phone",type:"phone"}
];
export default class AccountSearch extends LightningElement {

    columns = column;
    key;
    result;
    error;
    @wire(MessageContext)
    MessageContext;

    handleInput(event)
    {
     this.key = event.target.value;
     this.handleData();
     

    }
    handleData()
    {
        getAccount({'Search':this.key}).then( res => {
              this.result = res;
              this.handlePublish();
        }).catch( error =>{
            this.error = error;
        })

        
    }

    handlePublish()
    {
        let listId = [];
        for(let i =0;i<this.result.length;i++)
        {
            listId[i]=this.result[i].Id;
        }
        const payload = {inputValueMsg : listId}
        publish(this.MessageContext,testChannel,payload);
    }


}